#' @importFrom khisr khis_cred
#' @export
khisr::khis_cred

#' @importFrom khisr khis_has_cred
#' @export
khisr::khis_has_cred

#' @importFrom khisr khis_cred_clear
#' @export
khisr::khis_cred_clear

#' @importFrom khisr khis_username
#' @export
khisr::khis_username

#' @importFrom khisr khis_base_url
#' @export
khisr::khis_base_url
