#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`
